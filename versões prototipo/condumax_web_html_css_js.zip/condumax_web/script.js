// Comportamentos demonstrativos do protótipo.
// A autenticação real precisa ser conectada a um backend seguro.

const loginForm = document.querySelector("#login-form");
const feedback = document.querySelector("#feedback");
const forgotLink = document.querySelector("#forgot-link");

function showFeedback(message) {
  feedback.textContent = message;
  feedback.classList.add("visible");
}

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const username = document.querySelector("#username").value.trim();

  if (!username) {
    showFeedback("Digite seu usuário para continuar.");
    return;
  }

  showFeedback("Protótipo: formulário preenchido. A autenticação ainda não está conectada ao sistema.");
});

forgotLink.addEventListener("click", (event) => {
  event.preventDefault();
  showFeedback("Para recuperar sua senha, será necessário integrar este link ao processo de recuperação da empresa.");
});
